# IPP – App (ROOT version)

Ouvrez `https://<user>.github.io/<repo>/` directement.
- `index.html` à la racine
- `app.js` / `styles.css` à la racine
- `assets/` pour le logo
- `data/` pour questions et rapports
